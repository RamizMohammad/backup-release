"""
bakup — git-like backup. Run it inside a folder, just like git.

  bakup init                     # turn current folder into a bakup repo
  bakup config --server http://your-server:8000 --token SECRET   (global, once)
  bakup status                   # changes since last commit + server status
  bakup commit -m "msg"          # snapshot locally (works offline)
  bakup push                     # upload unpushed commits to the server
  bakup log                      # commit history (pushed / local)
  bakup restore <commit> <dest>  # pull a snapshot back from the server

Commits always work, online or offline — they store metadata (paths, sizes,
sha256 hashes) in .bakup/, like git. When offline, commit tells you the server
isn't connected. `push` uploads only content the server doesn't already have;
if the server is unreachable it says so and changes nothing.

State:
  ~/.bakup/config.json    global server url + token
  <repo>/.bakup/          repo name, stat-cache index, commit manifests
"""

import argparse, hashlib, json, os, re, sys, time, zlib
from pathlib import Path

import requests

from . import __version__

GLOBAL_CONFIG = Path(os.environ.get("BAKUP_HOME", Path.home() / ".bakup")) / "config.json"
IGNORE = {".bakup", ".git", "node_modules", "__pycache__", ".venv",
          "$RECYCLE.BIN", "System Volume Information", ".Trash-1000"}
SAFE = re.compile(r"^[a-zA-Z0-9._-]{1,80}$")
BATCH = 2000  # hashes per /missing request


# ---------- global config (server + token) ----------

def load_global():
    if GLOBAL_CONFIG.exists():
        return json.loads(GLOBAL_CONFIG.read_text())
    return {"server": "", "token": ""}

def save_global(cfg):
    GLOBAL_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    GLOBAL_CONFIG.write_text(json.dumps(cfg, indent=1))

def server_session():
    """Returns (session, base_url) or (None, None) if no server configured."""
    cfg = load_global()
    if not cfg["server"]:
        return None, None
    s = requests.Session()
    if cfg["token"]:
        s.headers["Authorization"] = f"Bearer {cfg['token']}"
    return s, cfg["server"].rstrip("/")

def server_online(s, base):
    try:
        return s.get(f"{base}/health", timeout=3).ok
    except requests.RequestException:
        return False


# ---------- repo discovery (walk up like git) ----------

def find_root():
    p = Path.cwd().resolve()
    for d in (p, *p.parents):
        if (d / ".bakup" / "repo.json").is_file():
            return d
    sys.exit("not a bakup repo (or any parent) — run: bakup init")

class Repo:
    def __init__(self, root: Path):
        self.root = root
        self.dir = root / ".bakup"
        self.name = json.loads((self.dir / "repo.json").read_text())["name"]
        self.index_p = self.dir / "index.json"
        self.commits = self.dir / "commits"

    def index(self):
        return json.loads(self.index_p.read_text()) if self.index_p.exists() else {}

    def commit_list(self):
        if not self.commits.exists():
            return []
        return [json.loads(p.read_text()) for p in sorted(self.commits.glob("*.json"))]

    def save_commit(self, m):
        self.commits.mkdir(parents=True, exist_ok=True)
        (self.commits / f"{m['id']}.json").write_text(json.dumps(m))


# ---------- hashing / scanning (git-style stat cache) ----------

def hash_file(path, bufsize=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(bufsize):
            h.update(chunk)
    return h.hexdigest()

def walk_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in IGNORE]
        for name in filenames:
            fp = Path(dirpath) / name
            try:
                yield fp.relative_to(root).as_posix(), fp, fp.stat()
            except OSError:
                continue  # vanished / permission denied

def scan(root: Path, index: dict):
    current, changes = {}, {"added": [], "modified": [], "deleted": []}
    seen = set()
    for rel, fp, st in walk_files(root):
        seen.add(rel)
        cached = index.get(rel)
        if cached and cached["mtime"] == st.st_mtime_ns and cached["size"] == st.st_size:
            current[rel] = cached
            continue
        try:
            digest = hash_file(fp)
        except OSError:
            continue
        current[rel] = {"mtime": st.st_mtime_ns, "size": st.st_size, "hash": digest}
        if cached is None:
            changes["added"].append(rel)
        elif cached["hash"] != digest:
            changes["modified"].append(rel)
    changes["deleted"] = sorted(set(index) - seen)
    return current, changes


# ---------- commands ----------

def cmd_init(args):
    root = Path.cwd().resolve()
    if (root / ".bakup" / "repo.json").is_file():
        sys.exit(f"already a bakup repo: {root}")
    name = args.name or root.name.lower().replace(" ", "-")
    if not SAFE.match(name):
        sys.exit(f"bad repo name '{name}' — use --name (letters, digits, . _ -)")
    (root / ".bakup").mkdir(exist_ok=True)
    (root / ".bakup" / "repo.json").write_text(json.dumps({"name": name}))
    print(f"initialized bakup repo '{name}' in {root}")

def cmd_config(args):
    cfg = load_global()
    if args.server: cfg["server"] = args.server
    if args.token is not None: cfg["token"] = args.token
    save_global(cfg)
    print(f"server: {cfg['server'] or '(unset)'}   token: {'set' if cfg['token'] else '(unset)'}")

def cmd_status(_):
    repo = Repo(find_root())
    _, ch = scan(repo.root, repo.index())
    total = len(ch["added"]) + len(ch["modified"]) + len(ch["deleted"])
    print(f"repo '{repo.name}' at {repo.root}")
    if total == 0:
        print("  working tree clean — nothing to commit")
    else:
        for kind, sym in (("added", "+"), ("modified", "~"), ("deleted", "-")):
            for rel in ch[kind][:20]:
                print(f"  {sym} {rel}")
            if len(ch[kind]) > 20:
                print(f"  ... and {len(ch[kind]) - 20} more {kind}")
        print(f"  {total} change(s) — run: bakup commit -m \"...\"")
    unpushed = [m for m in repo.commit_list() if not m.get("pushed")]
    if unpushed:
        print(f"  {len(unpushed)} commit(s) not yet pushed")
    s, base = server_session()
    if not s:
        print("  server: not configured (bakup config --server ...)")
    elif server_online(s, base):
        print(f"  server: connected ({base})")
    else:
        print(f"  server: NOT connected ({base}) — commits stay local until push")

def cmd_commit(args):
    repo = Repo(find_root())
    print(f"[{repo.name}] scanning {repo.root} ...")
    current, ch = scan(repo.root, repo.index())
    total = len(ch["added"]) + len(ch["modified"]) + len(ch["deleted"])
    if total == 0 and repo.commit_list():
        print("nothing to commit — working tree clean")
        return
    snap_id = time.strftime("%Y%m%d-%H%M%S")
    manifest = {"id": snap_id, "message": args.message, "time": time.time(),
                "source": str(repo.root), "pushed": False,
                "files": {rel: m["hash"] for rel, m in current.items()}}
    repo.save_commit(manifest)
    repo.index_p.write_text(json.dumps(current))
    print(f"[{repo.name}] commit {snap_id} — {len(current)} files "
          f"(+{len(ch['added'])} ~{len(ch['modified'])} -{len(ch['deleted'])})")
    s, base = server_session()
    if s and server_online(s, base):
        print("server connected — run 'bakup push' to upload")
    else:
        print("no server connected — commit saved locally, push when you're home")

def cmd_push(_):
    repo = Repo(find_root())
    s, base = server_session()
    if not s:
        sys.exit("no server configured — bakup config --server http://host:8000 --token ...")
    if not server_online(s, base):
        sys.exit(f"no server connected ({base}) — nothing pushed, try again at home")
    unpushed = [m for m in repo.commit_list() if not m.get("pushed")]
    if not unpushed:
        print("everything up to date")
        return

    for manifest in unpushed:  # oldest first
        files = manifest["files"]
        # 1) negotiate: which hashes does the server not have?
        all_hashes = list(set(files.values()))
        missing = set()
        for i in range(0, len(all_hashes), BATCH):
            r = s.post(f"{base}/repos/{repo.name}/objects/missing",
                       json=all_hashes[i:i + BATCH])
            r.raise_for_status()
            missing.update(r.json()["missing"])

        # 2) upload missing blobs from the working tree, verifying content
        #    still matches the committed hash (files may have changed since)
        by_hash = {}
        for rel, h in files.items():
            by_hash.setdefault(h, []).append(rel)
        lost, sent_bytes, n = set(), 0, 0
        for h in sorted(missing):
            uploaded = False
            for rel in by_hash[h]:
                fp = repo.root / rel
                try:
                    if hash_file(fp) != h:
                        continue  # changed since commit
                    data = zlib.compress(fp.read_bytes(), 6)
                except OSError:
                    continue
                r = s.put(f"{base}/repos/{repo.name}/objects/{h}", data=data,
                          headers={"Content-Type": "application/octet-stream"})
                r.raise_for_status()
                sent_bytes += len(data)
                uploaded = True
                break
            if not uploaded:
                lost.add(h)
            n += 1
            print(f"\r[{repo.name}] {manifest['id']}: uploading {n}/{len(missing)} "
                  f"objects ({sent_bytes / 1e6:.1f} MB sent)", end="", flush=True)
        if missing:
            print()

        # 3) push the manifest (drop entries whose content is gone)
        push_files = {rel: h for rel, h in files.items() if h not in lost}
        if lost:
            dropped = [rel for rel, h in files.items() if h in lost]
            print(f"[{repo.name}] warning: {len(dropped)} file(s) changed/deleted "
                  f"since commit and couldn't be uploaded: "
                  f"{', '.join(dropped[:5])}{' ...' if len(dropped) > 5 else ''}")
        server_manifest = {"id": manifest["id"], "message": manifest["message"],
                           "time": manifest["time"], "source": manifest["source"],
                           "files": push_files}
        r = s.put(f"{base}/repos/{repo.name}/snapshots/{manifest['id']}",
                  json=server_manifest)
        r.raise_for_status()
        manifest["pushed"] = True
        repo.save_commit(manifest)
        print(f"[{repo.name}] pushed {manifest['id']} — "
              f"{len(missing) - len(lost)} new objects, "
              f"{len(all_hashes) - len(missing)} already on server")

def cmd_log(_):
    repo = Repo(find_root())
    commits = repo.commit_list()
    if not commits:
        print("no commits yet")
        return
    for m in reversed(commits):
        t = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(m["time"]))
        mark = "✓ pushed" if m.get("pushed") else "○ local "
        print(f"{m['id']}  {t}  {mark}  ({len(m['files'])} files)  {m['message']}")

def cmd_restore(args):
    repo = Repo(find_root())
    s, base = server_session()
    if not s:
        sys.exit("no server configured")
    if not server_online(s, base):
        sys.exit(f"no server connected ({base}) — cannot restore")
    r = s.get(f"{base}/repos/{repo.name}/snapshots/{args.commit}")
    if r.status_code == 404:
        sys.exit("no such commit on server (was it pushed?)")
    r.raise_for_status()
    manifest = r.json()
    dst = Path(args.dest).resolve()
    for n, (rel, h) in enumerate(manifest["files"].items(), 1):
        out = (dst / rel).resolve()
        if not str(out).startswith(str(dst) + os.sep) and out != dst:
            print(f"\nskipping unsafe path in manifest: {rel}")
            continue
        rr = s.get(f"{base}/repos/{repo.name}/objects/{h}")
        rr.raise_for_status()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(zlib.decompress(rr.content))
        print(f"\rrestoring {n}/{len(manifest['files'])}", end="", flush=True)
    print(f"\nrestored {len(manifest['files'])} files to {dst}")


def main():
    ap = argparse.ArgumentParser(prog="bakup",
                                 description="git-like backup to your own server")
    ap.add_argument("--version", action="version", version=f"bakup {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init", help="make current folder a bakup repo")
    p.add_argument("--name"); p.set_defaults(fn=cmd_init)
    p = sub.add_parser("config", help="set server url/token (global, once)")
    p.add_argument("--server"); p.add_argument("--token"); p.set_defaults(fn=cmd_config)
    sub.add_parser("status", help="changes + server status").set_defaults(fn=cmd_status)
    p = sub.add_parser("commit", help="snapshot locally (works offline)")
    p.add_argument("-m", "--message", default=""); p.set_defaults(fn=cmd_commit)
    sub.add_parser("push", help="upload unpushed commits").set_defaults(fn=cmd_push)
    sub.add_parser("log", help="commit history").set_defaults(fn=cmd_log)
    p = sub.add_parser("restore", help="restore a pushed commit from the server")
    p.add_argument("commit"); p.add_argument("dest"); p.set_defaults(fn=cmd_restore)
    args = ap.parse_args()
    args.fn(args)

if __name__ == "__main__":
    main()
