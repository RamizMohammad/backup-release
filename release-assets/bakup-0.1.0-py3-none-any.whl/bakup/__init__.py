"""bakup — git-like backup to your own server."""
__version__ = "0.1.0"
